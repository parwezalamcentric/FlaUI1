# 🧮 Windows Calculator – FlaUI Automation Tests (Node.js)

Automated UI tests for the **Windows Calculator** app using [FlaUI.js](https://www.npmjs.com/package/@vavanya/flaui-js) — a Node.js binding for the .NET [FlaUI](https://github.com/FlaUI/FlaUI) framework.

## Prerequisites

| Requirement         | Details                                                   |
| ------------------- | --------------------------------------------------------- |
| **OS**              | Windows 10 / 11                                           |
| **Node.js**         | v18 or later (v21+ recommended)                           |
| **.NET Runtime**    | .NET 6+ (bundled with `@vavanya/flaui-js`)                |
| **Windows Calculator** | Must be installed (pre-installed on Windows 10/11)     |

## Project Structure

```
FlaUI1/
├── lib/
│   └── calculator-helper.mjs    # Page Object + shared utilities
├── tests/
│   ├── calculator-basic.mjs     # Basic arithmetic tests (10 tests)
│   ├── calculator-operations.mjs # Advanced operations tests (12 tests)
│   └── run-all-tests.mjs        # Runs all test suites sequentially
├── package.json
└── README.md
```

## Installation

```bash
npm install
```

## Running Tests

### Run basic arithmetic tests (addition, subtraction, multiplication, division)
```bash
npm run test:basic
```

### Run advanced operation tests (negate, percent, square root, decimals, etc.)
```bash
npm run test:operations
```

### Run all test suites
```bash
npm run test:all
```

### Run a specific test file directly
```bash
node tests/calculator-basic.mjs
```

## Test Coverage

### Basic Arithmetic (`calculator-basic.mjs`) — 10 Tests
| # | Test Case                          |
|---|------------------------------------|
| 1 | Addition: 123 + 4057 = 4180        |
| 2 | Subtraction: 5000 - 1234 = 3766    |
| 3 | Multiplication: 25 × 16 = 400      |
| 4 | Division: 144 ÷ 12 = 12            |
| 5 | Division with decimals: 10 ÷ 3     |
| 6 | Clear button resets to 0            |
| 7 | Chained addition: 10 + 20 + 30     |
| 8 | Mixed operations: 50 + 25 - 10     |
| 9 | Multiply by zero: 999 × 0          |
| 10| Large numbers: 99999 + 1           |

### Advanced Operations (`calculator-operations.mjs`) — 12 Tests
| # | Test Case                          |
|---|------------------------------------|
| 1 | Negate: 42 → -42                   |
| 2 | Double negate: 42 → -42 → 42       |
| 3 | Addition with negative number       |
| 4 | Decimal addition: 1.5 + 2.5         |
| 5 | Decimal multiplication: 3.14 × 2    |
| 6 | Square root: √144 = 12             |
| 7 | Square root: √2 ≈ 1.41421          |
| 8 | Square: 9² = 81                     |
| 9 | Backspace removes last digit        |
| 10| Percent: 200 + 10% = 220           |
| 11| Consecutive equals: 5 + 3 = = =    |
| 12| Subtraction to negative: 5 - 15    |

## Architecture

The project uses a **Page Object Model** pattern:

- **`CalculatorPage`** — Encapsulates all interactions with the Calculator UI (locators, clicks, result reading)
- **`TestRunner`** — A lightweight test runner that tracks pass/fail results and prints a summary
- **`assertEqual` / `assertApproxEqual`** — Simple assertion helpers

### Key API Usage (`@vavanya/flaui-js`)

```javascript
import { init } from '@vavanya/flaui-js';

const d = await init();
const Application = d.FlaUI.Core.Application;
const UIA3 = d.FlaUI.UIA3;

// Launch the Store app
const app = Application.LaunchStoreApp("Microsoft.WindowsCalculator_8wekyb3d8bbwe!App");
const automation = new UIA3.UIA3Automation();
const window = app.GetMainWindow(automation);

// Find elements by XPath
const btn = window.FindFirstByXPath("//Button[@Name='Five']");
btn.Click();
```

## Troubleshooting

| Issue | Solution |
|-------|---------|
| **Calculator doesn't launch** | Make sure Windows Calculator is installed: `Get-AppxPackage *Calculator*` in PowerShell |
| **Elements not found** | The Calculator UI may have changed in a Windows update. Inspect element names using **Accessibility Insights** or **FlaUI Inspect** |
| **Node.js version issues** | Use Node.js v18+ (v21+ recommended per FlaUI.js docs) |
| **Permission errors** | Run your terminal/VS Code as Administrator |

## License

ISC
