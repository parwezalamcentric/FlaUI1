import { defineConfig } from '@playwright/test';

/**
 * Playwright configuration for FlaUI-based Windows desktop tests.
 *
 * These tests do not use a browser. FlaUI drives Windows desktop apps while
 * Playwright provides the test runner and reporter.
 */
export default defineConfig({
  testDir: './tests',

  /* Desktop UI tests cannot run in parallel against the same interactive session. */
  fullyParallel: false,

  /* Fail the build on CI if test.only was left in source. */
  forbidOnly: !!process.env.CI,

  /* Retry on CI only. */
  retries: process.env.CI ? 2 : 0,

  /* Only one desktop app should be driven at a time. */
  workers: 1,

  /* Timeout per test. */
  timeout: 30_000,

  reporter: 'html',

  use: {
    trace: 'on-first-retry',
  },

  projects: [
    {
      name: 'Windows Desktop Apps',
      testMatch: /.*\.spec\.ts/,
    },
  ],
});
