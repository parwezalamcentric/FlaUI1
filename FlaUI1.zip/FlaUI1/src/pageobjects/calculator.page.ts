/**
 * CalculatorPage — Page Object Model for Windows Calculator.
 *
 * Mirrors CalculatorNodeJSPlaywrightRunner/src/pageobjects/calculator.page.ts
 * but uses FlaUI element handles instead of WebdriverIO selectors.
 */

const ELEMENT_WAIT_TIMEOUT_MS = 15_000;
const ELEMENT_POLL_INTERVAL_MS = 500;

/** Sleep helper */
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Wait for a UI element identified by XPath to appear.
 */
async function waitForElement(
    parent: any,
    xPath: string,
    timeoutMs: number = ELEMENT_WAIT_TIMEOUT_MS,
): Promise<any | null> {
    const maxAttempts = Math.ceil(timeoutMs / ELEMENT_POLL_INTERVAL_MS);
    let attempts = 0;
    let element: any = null;

    do {
        element = parent.FindFirstByXPath(xPath);
        if (element === null) {
            await sleep(ELEMENT_POLL_INTERVAL_MS);
        }
    } while (element === null && ++attempts < maxAttempts);

    return element;
}

export class CalculatorPage {
    private window: any;

    constructor(window: any) {
        this.window = window;
    }

    /**
     * Pause execution for the given number of milliseconds.
     */
    async pause(ms: number): Promise<void> {
        await sleep(ms);
    }

    // ── Element Locators ────────────────────────────────────────────────────

    private async getButton(name: string) {
        return waitForElement(this.window, `//Button[@Name='${name}']`);
    }

    private async getResultElement() {
        return waitForElement(this.window, "//Text[@AutomationId='CalculatorResults']");
    }

    // ── Result Helpers ──────────────────────────────────────────────────────

    /**
     * Reads the calculator result display and strips the "Display is " prefix.
     */
    async getResult(): Promise<string> {
        const el = await this.getResultElement();
        if (!el) throw new Error('Result element not found');
        const rawText: string = el.Name;
        return rawText.replace('Display is', '').replace(/,/g, '').trim();
    }

    /**
     * Get the numeric result from the display.
     */
    async getNumericResult(): Promise<number> {
        const text = await this.getResult();
        return parseFloat(text);
    }

    // ── Digit Input ─────────────────────────────────────────────────────────

    private static readonly DIGIT_NAMES = [
        'Zero', 'One', 'Two', 'Three', 'Four',
        'Five', 'Six', 'Seven', 'Eight', 'Nine',
    ];

    async clickDigit(digit: number): Promise<void> {
        const btn = await this.getButton(CalculatorPage.DIGIT_NAMES[digit]);
        if (!btn) throw new Error(`Digit button '${digit}' not found`);
        btn.Click();
        await sleep(200);
    }

    /**
     * Type a whole number by clicking each digit sequentially.
     */
    async typeNumber(value: number | string): Promise<void> {
        const chars = String(value).split('');
        for (const ch of chars) {
            if (ch === '.') {
                await this.clickDecimalSeparator();
            } else if (ch === '-') {
                await this.clickNegate();
            } else {
                await this.clickDigit(parseInt(ch, 10));
            }
        }
    }

    // ── Operator Buttons ────────────────────────────────────────────────────

    async clickPlus(): Promise<void> {
        const btn = await this.getButton('Plus');
        btn.Click();
        await sleep(200);
    }

    async clickMinus(): Promise<void> {
        const btn = await this.getButton('Minus');
        btn.Click();
        await sleep(200);
    }

    async clickMultiply(): Promise<void> {
        const btn = await this.getButton('Multiply by');
        btn.Click();
        await sleep(200);
    }

    async clickDivide(): Promise<void> {
        const btn = await this.getButton('Divide by');
        btn.Click();
        await sleep(200);
    }

    async clickEquals(): Promise<void> {
        const btn = await this.getButton('Equals');
        btn.Click();
        await sleep(200);
    }

    async clickClear(): Promise<void> {
        let btn = await waitForElement(this.window, "//Button[@Name='Clear']", 3000);
        if (!btn) {
            btn = await waitForElement(this.window, "//Button[@Name='Clear entry']", 3000);
        }
        if (btn) {
            btn.Click();
            await sleep(200);
        }
    }

    async clickDecimalSeparator(): Promise<void> {
        const btn = await this.getButton('Decimal separator');
        if (btn) {
            btn.Click();
            await sleep(200);
        }
    }

    async clickNegate(): Promise<void> {
        // Windows Calculator uses different names across OS versions
        const variants = [
            "//Button[@Name='Positive Negative']",
            "//Button[@Name='Negate']",
            "//Button[@AutomationId='negateButton']",
        ];
        let btn: any = null;
        for (const xpath of variants) {
            btn = await waitForElement(this.window, xpath, 2000);
            if (btn) break;
        }
        if (!btn) throw new Error('Negate button not found');
        btn.Click();
        await sleep(300);
    }

    async clickPercent(): Promise<void> {
        const btn = await this.getButton('Percent');
        if (btn) {
            btn.Click();
            await sleep(200);
        }
    }

    async clickSquareRoot(): Promise<void> {
        const btn = await this.getButton('Square root');
        if (btn) {
            btn.Click();
            await sleep(200);
        }
    }

    async clickSquare(): Promise<void> {
        const btn = await this.getButton('Square');
        if (btn) {
            btn.Click();
            await sleep(200);
        }
    }

    async clickBackspace(): Promise<void> {
        const btn = await this.getButton('Backspace');
        if (btn) {
            btn.Click();
            await sleep(200);
        }
    }
}
