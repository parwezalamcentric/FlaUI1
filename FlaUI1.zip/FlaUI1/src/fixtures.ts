/**
 * Playwright Fixtures for FlaUI-based Calculator tests.
 *
 * Mirrors the pattern in CalculatorNodeJSPlaywrightRunner/src/fixtures.ts exactly:
 * - flaApp is test-scoped so its teardown (including screenshot on failure) runs
 *   reliably after every test
 * - The FlaUI bridge singleton (init() can only be called once) is handled inside
 *   BaseTest.setup() via a module-level cache, so re-calling setup() per test is safe
 */
import { test as baseTest, expect } from '@playwright/test';
import { BaseTest } from './baseTest';
import { CalculatorPage } from './pageobjects/calculator.page';

// ---------------------------------------------------------------------------
// Fixture types
// ---------------------------------------------------------------------------

export type DesktopFixtures = {
    /** Manages the FlaUI session lifecycle (setup + teardown + screenshot on failure). */
    flaApp: BaseTest;
    /** Pre-built CalculatorPage POM, ready to use in desktop tests. */
    calcPage: CalculatorPage;
};

// ---------------------------------------------------------------------------
// Extend Playwright's test object with FlaUI desktop fixtures
// ---------------------------------------------------------------------------
export const test = baseTest.extend<DesktopFixtures>({

    // The flaApp fixture: launches the Calculator and attaches a screenshot on failure.
    // Test-scoped (default) so teardown runs after EVERY test — same as winApp in the reference.
    flaApp: async ({}, use, testInfo) => {
        const app = new BaseTest();
        await app.setup();  // Runs before the test

        await use(app);     // Suspends here while the test executes

        // Runs after the test finishes — capture screenshot if test failed
        if (testInfo.status !== testInfo.expectedStatus) {
            try {
                const screenshot = app.captureScreenshot();
                if (screenshot) {
                    await testInfo.attach('failure-screenshot', {
                        body: screenshot,
                        contentType: 'image/png',
                    });
                }
            } catch (_) {
                // Ignore screenshot errors so teardown always completes
            }
        }

        await app.teardown();
    },

    // The calcPage fixture: clears the display then hands a CalculatorPage to the test.
    calcPage: async ({ flaApp }, use) => {
        const calcPage = new CalculatorPage(flaApp.window);
        await calcPage.clickClear();
        await use(calcPage);
    },
});

// Re-export expect so specs can import { test, expect } from one place
export { expect };
