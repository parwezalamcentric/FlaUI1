/**
 * Calculator Advanced Operations Tests — Playwright runner + FlaUI
 *
 * Converted from tests/calculator-operations.mjs (custom runner)
 * to Playwright's test.describe / test() / expect() pattern.
 */
import { test, expect } from '../src/fixtures';

test.describe('Calculator – Advanced Operations', () => {
    test.setTimeout(30_000);

    test('Negate: 42 → -42', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(42);
        await calcPage.clickNegate();
        await calcPage.pause(300);

        const result = await calcPage.getNumericResult();
        expect(result).toBe(-42);
    });

    test('Double negate: 42 → -42 → 42', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(42);
        await calcPage.clickNegate();
        await calcPage.pause(300);
        await calcPage.clickNegate();
        await calcPage.pause(300);

        const result = await calcPage.getNumericResult();
        expect(result).toBe(42);
    });

    test('Addition with negative: 100 + (-30) = 70', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(100);
        await calcPage.clickPlus();
        await calcPage.typeNumber(30);
        await calcPage.clickNegate();
        await calcPage.pause(300);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(70);
    });

    test('Decimal addition: 1.5 + 2.5 = 4', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber('1.5');
        await calcPage.clickPlus();
        await calcPage.typeNumber('2.5');
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(4);
    });

    test('Decimal multiplication: 3.14 × 2 = 6.28', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber('3.14');
        await calcPage.clickMultiply();
        await calcPage.typeNumber(2);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBeCloseTo(6.28, 2);
    });

    test('Square root: √144 = 12', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(144);
        await calcPage.clickSquareRoot();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(12);
    });

    test('Square root: √2 ≈ 1.41421', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(2);
        await calcPage.clickSquareRoot();

        const result = await calcPage.getNumericResult();
        expect(result).toBeCloseTo(1.41421356, 4);
    });

    test('Square: 9² = 81', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(9);
        await calcPage.clickSquare();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(81);
    });

    test('Backspace removes last digit: 123 → 12', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(123);
        await calcPage.clickBackspace();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(12);
    });

    test('Percent: 200 + 10% = 220', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(200);
        await calcPage.clickPlus();
        await calcPage.typeNumber(10);
        await calcPage.clickPercent();
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(220);
    });

    test('Consecutive equals: 5 + 3 = = = → 14', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(5);
        await calcPage.clickPlus();
        await calcPage.typeNumber(3);
        await calcPage.clickEquals(); // 8
        await calcPage.clickEquals(); // 11
        await calcPage.clickEquals(); // 14

        const result = await calcPage.getNumericResult();
        expect(result).toBe(14);
    });

    test('Subtraction to negative: 5 - 15 = -10', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(5);
        await calcPage.clickMinus();
        await calcPage.typeNumber(15);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(-10);
    });
});
