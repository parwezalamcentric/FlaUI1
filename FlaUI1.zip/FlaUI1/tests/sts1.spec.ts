import { test as base, expect } from '@playwright/test';
import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { getFlauiBridge } from '../src/baseTest';

const STS_EXE_PATH = 'C:\\Program Files\\PrattMiller\\VES2\\Desktop\\SimToolSuite.exe';
const STS_WINDOW_TITLE = 'Sim Tool Suite';
const WINDOW_WAIT_TIMEOUT_MS = 20_000;
const POLL_INTERVAL_MS = 500;

type StsApp = {
    app: any;
    automation: any;
    window: any;
    windowTitle: string;
    processId: number;
};

type StsFixtures = {
    stsApp: StsApp;
};

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function isProcessRunning(processId: number): boolean {
    try {
        const output = execFileSync('tasklist', ['/FI', `PID eq ${processId}`, '/FO', 'CSV', '/NH'], {
            encoding: 'utf8',
            stdio: ['ignore', 'pipe', 'ignore'],
        });
        return output.includes(`"${processId}"`);
    } catch (_) {
        return false;
    }
}

function getProcessMainWindowTitle(processId: number): string {
    try {
        return execFileSync(
            'powershell.exe',
            ['-NoProfile', '-Command', `(Get-Process -Id ${processId} -ErrorAction Stop).MainWindowTitle`],
            {
                encoding: 'utf8',
                stdio: ['ignore', 'pipe', 'ignore'],
            },
        ).trim();
    } catch (_) {
        return '';
    }
}

async function waitForProcessMainWindowTitle(processId: number): Promise<string> {
    const maxAttempts = Math.ceil(WINDOW_WAIT_TIMEOUT_MS / POLL_INTERVAL_MS);

    for (let attempt = 0; attempt < maxAttempts; attempt++) {
        const title = getProcessMainWindowTitle(processId);
        if (title.includes(STS_WINDOW_TITLE)) {
            return title;
        }
        await sleep(POLL_INTERVAL_MS);
    }

    throw new Error(`Timed out waiting for Sim Tool Suite process ${processId} to show "${STS_WINDOW_TITLE}"`);
}

async function getFlaUiMainWindow(app: any, automation: any, processId: number): Promise<any> {
    const maxAttempts = Math.ceil(WINDOW_WAIT_TIMEOUT_MS / POLL_INTERVAL_MS);
    let lastError: unknown;

    for (let attempt = 0; attempt < maxAttempts; attempt++) {
        try {
            const window = app.GetMainWindow(automation);
            if (window && String(window.Name ?? '').length > 0) {
                return window;
            }
        } catch (err) {
            lastError = err;
        }
        await sleep(POLL_INTERVAL_MS);
    }

    if (lastError instanceof Error) {
        throw new Error(`Timed out waiting for a FlaUI window for process ${processId}: ${lastError.message}`);
    }

    throw new Error(`Timed out waiting for a FlaUI window for process ${processId}`);
}

async function closeStsApp(stsApp: Partial<StsApp> | undefined): Promise<void> {
    if (!stsApp) {
        return;
    }

    if (stsApp.processId && isProcessRunning(stsApp.processId)) {
        try {
            execFileSync('taskkill', ['/PID', String(stsApp.processId), '/T', '/F'], {
                stdio: 'ignore',
            });
        } catch (_) {
            // The process may have exited between the tasklist and taskkill calls.
        }
    }

    try {
        stsApp.automation?.Dispose();
    } catch (_) {
        // Ignore automation teardown errors.
    }
}

const test = base.extend<StsFixtures>({
    stsApp: async ({}, use) => {
        if (!existsSync(STS_EXE_PATH)) {
            throw new Error(`Sim Tool Suite executable not found at ${STS_EXE_PATH}`);
        }

        const d = await getFlauiBridge();
        const automation = new d.FlaUI.UIA2.UIA2Automation();
        let stsApp: StsApp | undefined;

        try {
            const app = d.FlaUI.Core.Application.Launch(STS_EXE_PATH);

            const processId = Number(app.ProcessId);
            const windowTitle = await waitForProcessMainWindowTitle(processId);
            const window = await getFlaUiMainWindow(app, automation, processId);

            stsApp = { app, automation, window, windowTitle, processId };
            await use(stsApp);
        } finally {
            await closeStsApp(stsApp ?? { automation });
        }
    },
});

test.describe('Sim Tool Suite smoke tests', () => {
    test('executable is installed', async () => {
        expect(existsSync(STS_EXE_PATH)).toBe(true);
    });

    test('launches the application process', async ({ stsApp }) => {
        expect(stsApp.processId).toBeGreaterThan(0);
        expect(isProcessRunning(stsApp.processId)).toBe(true);
    });

    test('shows the main window', async ({ stsApp }) => {
        expect(stsApp.windowTitle).toContain(STS_WINDOW_TITLE);
    });

    test('exposes a top-level window through FlaUI', async ({ stsApp }) => {
        expect(stsApp.window).toBeTruthy();
        expect(String(stsApp.window.Name ?? '')).not.toHaveLength(0);
    });
});
