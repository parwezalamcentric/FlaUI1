/**
 * Calculator Deliberate Failure Test
 * ───────────────────────────────────
 * This spec contains an intentionally failing test to verify that:
 * 1. Failure screenshots are captured and attached to the Playwright HTML report
 * 2. The test runner correctly reports failures
 *
 * Run: npm run test:fail
 */
import { test, expect } from '../src/fixtures';

test.describe('Calculator – Deliberate Failure', () => {
    test.setTimeout(30_000);

    test('Intentionally Failing Test: 2 + 2 = 99', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(2);
        await calcPage.clickPlus();
        await calcPage.typeNumber(2);
        await calcPage.clickEquals();

        const result = await calcPage.getResult();
        console.log('Result:', result);

        // This assertion will intentionally fail — 2 + 2 is 4, not 99
        // A failure screenshot should be attached to the Playwright HTML report
        expect(result).toBe('99');
    });
});
