/**
 * Calculator Basic Arithmetic Tests — Playwright runner + FlaUI
 *
 * Converted from tests/calculator-basic.mjs (custom runner)
 * to Playwright's test.describe / test() / expect() pattern.
 */
import { test, expect } from '../src/fixtures';

test.describe('Calculator – Basic Arithmetic', () => {
    test.setTimeout(30_000);

    test('Addition: 123 + 4057 = 4180', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(123);
        await calcPage.clickPlus();
        await calcPage.typeNumber(4057);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(4180);
    });

    test('Subtraction: 5000 - 1234 = 3766', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(5000);
        await calcPage.clickMinus();
        await calcPage.typeNumber(1234);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(3766);
    });

    test('Multiplication: 25 × 16 = 400', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(25);
        await calcPage.clickMultiply();
        await calcPage.typeNumber(16);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(400);
    });

    test('Division: 144 ÷ 12 = 12', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(144);
        await calcPage.clickDivide();
        await calcPage.typeNumber(12);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(12);
    });

    test('Division with decimal result: 10 ÷ 3 ≈ 3.333', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(10);
        await calcPage.clickDivide();
        await calcPage.typeNumber(3);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBeCloseTo(3.3333333, 2);
    });

    test('Clear button resets display to 0', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.typeNumber(999);
        await calcPage.clickClear();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(0);
    });

    test('Chained addition: 10 + 20 + 30 = 60', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(10);
        await calcPage.clickPlus();
        await calcPage.typeNumber(20);
        await calcPage.clickPlus();
        await calcPage.typeNumber(30);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(60);
    });

    test('Mixed operations: 50 + 25 - 10 = 65', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(50);
        await calcPage.clickPlus();
        await calcPage.typeNumber(25);
        await calcPage.clickMinus();
        await calcPage.typeNumber(10);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(65);
    });

    test('Multiply by zero: 999 × 0 = 0', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(999);
        await calcPage.clickMultiply();
        await calcPage.typeNumber(0);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(0);
    });

    test('Large numbers: 99999 + 1 = 100000', async ({ calcPage }) => {
        await calcPage.pause(1000);
        await calcPage.clickClear();
        await calcPage.typeNumber(99999);
        await calcPage.clickPlus();
        await calcPage.typeNumber(1);
        await calcPage.clickEquals();

        const result = await calcPage.getNumericResult();
        expect(result).toBe(100000);
    });
});
