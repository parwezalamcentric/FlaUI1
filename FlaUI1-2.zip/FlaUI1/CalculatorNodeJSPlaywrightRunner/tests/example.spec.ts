import { test, expect } from '../src/fixtures';

test('has title', async ({ basePage }) => {
  await basePage.goto('https://playwright.dev/');

  // Expect a title "to contain" a substring.
  await expect(basePage).toHaveTitle(/Playwright/);
});

test('get started link', async ({ basePage }) => {
  await basePage.goto('https://playwright.dev/');

  // Click the get started link.
  await basePage.getByRole('link', { name: 'Get started' }).click();

  // Expects page to have a heading with the name of Installation.
  await expect(basePage.getByRole('heading', { name: 'Installation' })).toBeVisible();
});
