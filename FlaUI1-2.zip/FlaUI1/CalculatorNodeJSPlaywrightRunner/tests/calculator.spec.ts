import { test, expect } from '../src/fixtures';

test.describe('Calculator Tests', () => {
    test.setTimeout(30000);

    test('testAddition: 1 + 2 = 3', async ({ calcPage }) => {
        // Wait for the app to be fully loaded
        await calcPage.pause(1000);

        // Perform calculation: 1 + 2 = 3
        await calcPage.num1.click();
        await calcPage.plus.click();
        await calcPage.num2.click();
        await calcPage.equals.click();

        // Verify result
        const result = await calcPage.getResult();
        console.log('Result:', result);

        expect(result).toBe('3');
    });

    test('deliberateFailure: 2 + 2 = 99 (Intentionally Failing Test)', async ({ calcPage }) => {
        await calcPage.pause(1000);

        // Perform computation: 2 + 2
        await calcPage.num2.click();
        await calcPage.plus.click();
        await calcPage.num2.click();
        await calcPage.equals.click();

        const result = await calcPage.getResult();
        console.log('Result:', result);

        // This assertion will forcefully fail the test and automatically invoke our screenshot hook!
        expect(result).toBe('99');
    });

});

