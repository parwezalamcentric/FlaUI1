import { remote, type Browser } from 'webdriverio';

export const WIN_APP_DRIVER_HOST = process.env.WAD_HOST || '127.0.0.1';
export const WIN_APP_DRIVER_PORT = process.env.WAD_PORT || 4723;
export const WIN_APP_DRIVER_URL = `http://${WIN_APP_DRIVER_HOST}:${WIN_APP_DRIVER_PORT}`;

// Helper: click an element by posting directly to WinAppDriver's element click endpoint.
export async function winClickRequest(sessionId: string, elementId: string): Promise<void> {
    const res = await fetch(`${WIN_APP_DRIVER_URL}/session/${sessionId}/element/${elementId}/click`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
    if (!res.ok) throw new Error(`Click failed with status: ${res.status}`);
}

export class BaseTest {
    public driver!: Browser;

    async setup() {
        this.driver = await remote({
            hostname: WIN_APP_DRIVER_HOST,
            port: Number(WIN_APP_DRIVER_PORT),
            path: '/',
            // WinAppDriver uses the legacy JSON Wire Protocol, not W3C
            strictSSL: false,
            capabilities: {
                platformName: 'Windows',
                app: 'Microsoft.WindowsCalculator_8wekyb3d8bbwe!App',
                deviceName: 'WindowsPC'
            } as WebdriverIO.Capabilities
        });

        // Overwrite standard WebdriverIO Element Click logic to bypass W3C natively universally
        const sessionId = this.driver.sessionId;
        this.driver.overwriteCommand('click', async function (this: WebdriverIO.Element, origClick) {
            await winClickRequest(sessionId, this.elementId);
        }, true);

        console.log('App launched!');
    }

    async teardown() {
        if (this.driver && this.driver.sessionId) {
            try {
                // WinAppDriver returns an empty 200 OK on DELETE which causes WebdriverIO's W3C parser to fail
                // and aggressively retry resulting in 404s. Hitting the endpoint natively bypasses the noisy console logs!
                await fetch(`${WIN_APP_DRIVER_URL}/session/${this.driver.sessionId}`, {
                    method: 'DELETE'
                });
            } catch (_) {
                // Session may already be closed
            }
        }
    }
}
