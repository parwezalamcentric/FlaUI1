import type { Browser } from 'webdriverio';

export class CalculatorPage {
    private driver: Browser;

    constructor(driver: Browser) {
        this.driver = driver;
    }

    /**
     * Pause execution for the given number of milliseconds.
     * Useful to wait for the app to finish launching before interacting.
     */
    async pause(ms: number): Promise<void> {
        await this.driver.pause(ms);
    }

    /**
     * Define selectors using Page Object pattern logic.
     */
    get num1() { return this.driver.$('[name="One"]'); }
    get num2() { return this.driver.$('[name="Two"]'); }
    get plus() { return this.driver.$('[name="Plus"]'); }
    get equals() { return this.driver.$('[name="Equals"]'); }
    get results() { return this.driver.$('~CalculatorResults'); }

    /**
     * Reads the calculator result display and strips prefix text
     */
    async getResult(): Promise<string> {
        const resultsEl = await this.results;
        const rawText = await resultsEl.getText();
        return rawText.replace('Display is', '').trim();
    }
}
