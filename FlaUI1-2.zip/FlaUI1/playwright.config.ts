import { defineConfig } from '@playwright/test';

/**
 * Playwright configuration for FlaUI-based Windows Calculator tests.
 *
 * These tests do NOT use a browser — they use FlaUI (.NET UI Automation)
 * under the hood. Playwright is used purely as a test runner & reporter.
 */
export default defineConfig({
  testDir: './tests',

  /* Run tests sequentially — desktop UI tests cannot run in parallel */
  fullyParallel: false,

  /* Fail the build on CI if you accidentally left test.only in the source code */
  forbidOnly: !!process.env.CI,

  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,

  /* Single worker — only one Calculator instance at a time */
  workers: 1,

  /* Timeout per test (30 seconds) */
  timeout: 30_000,

  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: 'html',

  use: {
    trace: 'on-first-retry',
  },

  projects: [
    {
      name: 'Windows Desktop Calculator',
      testMatch: /.*\.spec\.ts/,
    },
  ],
});
