/**
 * BaseTest — manages the FlaUI lifecycle (launch ↔ teardown) for the Calculator app.
 *
 * Mirrors the pattern in CalculatorNodeJSPlaywrightRunner/src/baseTest.ts
 * but replaces WinAppDriver with FlaUI.js (.NET UI Automation).
 *
 * IMPORTANT: The FlaUI bridge (`init()`) can only be called ONCE per Node.js
 * process. We cache the result in a module-level singleton so that every
 * BaseTest instance reuses the same .NET interop bridge.
 */

// @ts-ignore — flaui-js ships without type declarations
import { init } from '@vavanya/flaui-js';
import { execSync } from 'node:child_process';
import { readFileSync, unlinkSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

const CALCULATOR_APP_ID = 'Microsoft.WindowsCalculator_8wekyb3d8bbwe!App';

// ── Singleton: FlaUI bridge can only be initialised once per process ─────────
let _flauiBridge: any = null;
let _flauiBridgePromise: Promise<any> | null = null;

async function getFlauiBridge(): Promise<any> {
    if (_flauiBridge) return _flauiBridge;
    if (!_flauiBridgePromise) {
        _flauiBridgePromise = init().then((d: any) => {
            _flauiBridge = d;
            return d;
        });
    }
    return _flauiBridgePromise;
}

export class BaseTest {
    public flaui: any;
    public app: any;
    public window: any;
    public automation: any;

    /**
     * Launch the Calculator via FlaUI and obtain the main window handle.
     */
    async setup(): Promise<void> {
        const d = await getFlauiBridge();

        this.flaui = {
            UIA3: d.FlaUI.UIA3,
            Core: d.FlaUI.Core,
            Input: d.FlaUI.Core.Input,
            Application: d.FlaUI.Core.Application,
        };

        this.automation = new this.flaui.UIA3.UIA3Automation();
        this.app = this.flaui.Application.LaunchStoreApp(CALCULATOR_APP_ID);
        this.app.WaitWhileBusy();
        this.window = this.app.GetMainWindow(this.automation);

        // Allow the UI to fully render
        await new Promise((r) => setTimeout(r, 1500));

        console.log('Calculator launched via FlaUI!');
    }

    captureScreenshot(): Buffer | null {
        if (!this.window || !this.flaui?.Core?.Capturing?.Capture) {
            console.log('[screenshot] FlaUI capture unavailable');
            return null;
        }
        const tempPng = join(tmpdir(), `flaui-screenshot-${Date.now()}.png`);
        try {
            const img = this.flaui.Core.Capturing.Capture.Element(this.window);
            img.ToFile(tempPng);
            if (existsSync(tempPng)) {
                const buffer = readFileSync(tempPng);
                unlinkSync(tempPng);
                return buffer;
            }
            return null;
        } catch (err: any) {
            console.log(`[screenshot] ERROR: ${err?.message}`);
            try { if (existsSync(tempPng)) unlinkSync(tempPng); } catch (__) { /* ignore */ }
            return null;
        }
    }

    /**
     * Close the Calculator application.
     */
    async teardown(): Promise<void> {
        if (this.app) {
            try {
                this.app.Close();
            } catch (_) {
                // App may already be closed
            }
        }
    }
}
