import { test, expect } from '../src/fixtures';
import { WebDriver, By, WebElement } from 'selenium-webdriver';

const WINDOW_WAIT_TIMEOUT_MS = 45_000;
const POLL_INTERVAL_MS = 500;
const STS_WINDOW_TITLE = 'Sim Tool Suite';
const PROJECT_NAME = 'Centric Test';

async function waitForElement(driver: WebDriver, selector: string, timeout = WINDOW_WAIT_TIMEOUT_MS): Promise<WebElement> {
    const deadline = Date.now() + timeout;

    while (Date.now() < deadline) {
        const elements = await driver.findElements(By.xpath(selector));
        if (elements.length > 0) {
            return elements[0];
        }

        await new Promise(resolve => setTimeout(resolve, POLL_INTERVAL_MS));
    }

    throw new Error(`Timed out waiting for selector: ${selector}`);
}

test.describe('Sim Tool Suite project selection tests', () => {
    test.describe.configure({ timeout: 150000 });

    test('launch: Sim Tool Suite window should be available', async ({ stsApp, stsPage }) => {
        await stsPage.pause(2000);

        const visible = await stsPage.isProjectSelectorVisible(45_000);
        const title = await stsApp.driver.getTitle();

        expect(visible, 'Project selector should be visible').toBe(true);
        expect(title).toContain(STS_WINDOW_TITLE);
    });

    test('project selector: should select Centric Test project', async ({ stsApp, stsPage }) => {
        const driver = stsApp.driver;

        const projectSelector = await waitForElement(driver, '//*[@Name="LookUpEdit"]');
        expect(
            (await driver.findElements(By.xpath('//*[@Name="LookUpEdit"]'))).length > 0,
            'LookUpEdit control should be present'
        ).toBe(true);

        const dropDownButton = await projectSelector.findElement(By.xpath('.//Button'));
        expect(
            (await projectSelector.findElements(By.xpath('.//Button'))).length > 0,
            'Drop-down button inside LookUpEdit should be present'
        ).toBe(true);

        await dropDownButton.click();
        await driver.sleep(2000); // wait for project list to populate

        const centricTestItem = await waitForElement(driver, `//*[contains(@Name,"${PROJECT_NAME}")]`);
        expect(
            (await driver.findElements(By.xpath(`//*[contains(@Name,"${PROJECT_NAME}")]`))).length > 0,
            `"${PROJECT_NAME}" item should appear in the drop-down`
        ).toBe(true);

        await centricTestItem.click();
        await driver.sleep(7000);

        expect(await stsPage.isAppVisible(), 'App should still be running after project selection').toBe(true);
    });
});
