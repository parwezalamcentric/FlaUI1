import { WebDriver, Session } from 'selenium-webdriver';
import { HttpClient, Executor } from 'selenium-webdriver/http';
import { execFileSync } from 'node:child_process';
import { win32 as path } from 'node:path';

export const WIN_APP_DRIVER_HOST = process.env.WAD_HOST || '127.0.0.1';
export const WIN_APP_DRIVER_PORT = process.env.WAD_PORT || 4723;
export const WIN_APP_DRIVER_URL = `http://${WIN_APP_DRIVER_HOST}:${WIN_APP_DRIVER_PORT}`;

export const CALCULATOR_APP   = 'Microsoft.WindowsCalculator_8wekyb3d8bbwe!App';
export const STS_APP_PATH     = process.env.STS_APP_PATH
    || 'C:\\Program Files\\PrattMiller\\VES2\\Desktop\\SimToolSuite.exe';

export class BaseTest {
    public driver!: WebDriver;
    private appPath: string;

    constructor(appPath: string = CALCULATOR_APP) {
        this.appPath = appPath;
    }

    async setup() {
        // selenium-webdriver v4 dropped JSON Wire Protocol (JSONWP) support and
        // sends only W3C capabilities (alwaysMatch / firstMatch). WinAppDriver only
        // speaks JSONWP and therefore never sees the `app` key in a W3C request.
        // Solution: create the session with a raw JSONWP POST, grab the sessionId,
        // then attach selenium-webdriver to that existing session so all subsequent
        // commands (findElement, click, etc.) work normally.
        //
        // ms:waitForAppLaunch (max 50) tells WinAppDriver to keep polling internally
        // until the application window appears before returning — no retry loop needed
        // and no risk of spawning multiple orphaned processes.
        const res = await fetch(`${WIN_APP_DRIVER_URL}/session`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                desiredCapabilities: {
                    platformName: 'Windows',
                    app: this.appPath,
                    deviceName: 'WindowsPC',
                    'ms:waitForAppLaunch': '50',
                },
            }),
        });

        if (!res.ok) {
            const text = await res.text();
            throw new Error(`WinAppDriver session creation failed (HTTP ${res.status}): ${text}`);
        }

        const data = await res.json() as { sessionId: string };
        const executor = new Executor(new HttpClient(WIN_APP_DRIVER_URL));
        const session = new Session(data.sessionId, {});
        this.driver = new WebDriver(session, executor);
        console.log('App launched!');
    }

    private closeLaunchedExeProcess() {
        if (!this.appPath.toLowerCase().endsWith('.exe')) {
            return;
        }

        const exeName = path.basename(this.appPath);

        try {
            execFileSync('taskkill', ['/IM', exeName, '/T', '/F'], {
                stdio: 'ignore',
            });
        } catch (_) {
            // The app may have already closed during session teardown.
        }
    }

    async teardown() {
        if (this.driver) {
            try {
                await this.driver.quit();
            } catch (_) {
                // Session may already be closed.
            }
        }

        this.closeLaunchedExeProcess();
    }
}
