import { test as baseTest, expect, type Page } from '@playwright/test';
import { BaseTest, STS_APP_PATH } from './baseTest';
import { CalculatorPage } from './pageobjects/calculator.page';
import { StsPage } from './pageobjects/sts.page';

// ---------------------------------------------------------------------------
// Desktop (WinAppDriver) fixtures
// ---------------------------------------------------------------------------
export type DesktopFixtures = {
    /** Manages the WinAppDriver session lifecycle (setup + teardown + screenshot on failure). */
    winApp: BaseTest;
    /** Pre-built CalculatorPage POM, ready to use in desktop tests. */
    calcPage: CalculatorPage;
};

// ---------------------------------------------------------------------------
// SimToolSuite fixtures
// ---------------------------------------------------------------------------
export type StsFixtures = {
    /** Manages the WinAppDriver session for SimToolSuite (setup + teardown + screenshot on failure). */
    stsApp: BaseTest;
    /** Pre-built StsPage POM, ready to use in SimToolSuite tests. */
    stsPage: StsPage;
};

// ---------------------------------------------------------------------------
// Web UI fixtures
// ---------------------------------------------------------------------------
export type WebFixtures = {
    /** The Playwright browser page, re-exposed so Web UI tests can import from this module too. */
    basePage: Page;
};

// ---------------------------------------------------------------------------
// Combined fixture type — covers both Desktop and Web UI tests in this workspace
// ---------------------------------------------------------------------------
export type AllFixtures = DesktopFixtures & StsFixtures & WebFixtures;

// Extend the native Playwright test object providing all custom fixtures
export const test = baseTest.extend<AllFixtures>({

    // ── Desktop ──────────────────────────────────────────────────────────────

    // The winApp fixture: launches the Windows App and attaches a screenshot on failure.
    winApp: async ({}, use, testInfo) => {
        const app = new BaseTest();
        await app.setup();  // Automatically runs before the test

        await use(app);     // Suspends fixture and executes the test

        // Automatically runs after the test finishes
        if (testInfo.status !== 'passed' && app.driver) {
            try {
                const screenshot = await app.driver.takeScreenshot();
                await testInfo.attach('failure-screenshot', {
                    body: Buffer.from(screenshot, 'base64'),
                    contentType: 'image/png',
                });
            } catch (_) {
                // Ignore screenshot errors
            }
        }

        await app.teardown();
    },

    // The calcPage fixture: instantiates the CalculatorPage POM using the running winApp driver.
    calcPage: async ({ winApp }, use) => {
        const calcPage = new CalculatorPage(winApp.driver);
        await use(calcPage);
    },

    // ── SimToolSuite ──────────────────────────────────────────────────────────

    // The stsApp fixture: launches SimToolSuite.exe and attaches a screenshot on failure.
    stsApp: async ({}, use, testInfo) => {
        const app = new BaseTest(STS_APP_PATH);
        await app.setup();

        await use(app);

        if (testInfo.status !== 'passed' && app.driver) {
            try {
                const screenshot = await app.driver.takeScreenshot();
                await testInfo.attach('failure-screenshot', {
                    body: Buffer.from(screenshot, 'base64'),
                    contentType: 'image/png',
                });
            } catch (_) {
                // Ignore screenshot errors
            }
        }

        await app.teardown();
    },

    // The stsPage fixture: instantiates the StsPage POM using the running stsApp driver.
    stsPage: async ({ stsApp }, use) => {
        const page = new StsPage(stsApp.driver);
        await use(page);
    },

    // ── Web UI ───────────────────────────────────────────────────────────────

    // The basePage fixture: thin wrapper around Playwright's built-in `page` fixture.
    // Web UI tests that import from this module receive the same `page` they would
    // get from @playwright/test, but through the unified fixture chain.
    basePage: async ({ page }, use) => {
        await use(page);
    },
});

// Export standard expectations so test suites can naturally import { test, expect }
export { expect };
