import { WebDriver, By, WebElement } from 'selenium-webdriver';

const PROJECT_SELECTOR_XPATH = '//*[@Name="LookUpEdit"]';
const POLL_INTERVAL_MS = 500;

export class StsPage {
    private driver: WebDriver;

    constructor(driver: WebDriver) {
        this.driver = driver;
    }

    /**
     * Pause execution for the given number of milliseconds.
     * Useful to wait for the app to finish launching before interacting.
     */
    async pause(ms: number): Promise<void> {
        await new Promise(resolve => setTimeout(resolve, ms));
    }

    // ── Main Window ─────────────────────────────────────────────────────────
    // WinAppDriver supports XPath over Windows accessibility properties.
    get mainWindow()      { return this.driver.findElement(By.xpath('//*[@Name="SimToolSuite"]')); }

    // ── Menu Bar ─────────────────────────────────────────────────────────────
    get fileMenu()        { return this.driver.findElement(By.xpath('//*[@Name="File"]')); }
    get helpMenu()        { return this.driver.findElement(By.xpath('//*[@Name="Help"]')); }
    get projectSelector() { return this.driver.findElement(By.xpath(PROJECT_SELECTOR_XPATH)); }

    // ── Title Bar ────────────────────────────────────────────────────────────
    get titleBar()        { return this.driver.findElement(By.xpath('//*[@Name="SimToolSuite"]')); }

    /**
     * Returns the window title text.
     */
    async getTitle(): Promise<string> {
        const el = await this.titleBar;
        return el.getText();
    }

    /**
     * Returns true if the main application window is visible.
     * Uses takeScreenshot() as the visibility probe because it is proven to
     * succeed once WinAppDriver has an active session — unlike element lookups
     * which require knowing the exact accessibility name up front.
     */
    async isAppVisible(): Promise<boolean> {
        try {
            const screenshot = await this.driver.takeScreenshot();
            return screenshot.length > 0;
        } catch {
            return false;
        }
    }

    async waitForProjectSelector(timeoutMs = 20_000): Promise<WebElement> {
        const deadline = Date.now() + timeoutMs;

        while (Date.now() < deadline) {
            try {
                const elements = await this.driver.findElements(By.xpath(PROJECT_SELECTOR_XPATH));
                if (elements.length > 0) {
                    return elements[0];
                }
            } catch {
                // Keep polling while the app finishes loading.
            }

            await this.pause(POLL_INTERVAL_MS);
        }

        throw new Error(`Timed out waiting for project selector: ${PROJECT_SELECTOR_XPATH}`);
    }

    /**
     * Returns true when the project selector is present.
     * WinAppDriver can report custom desktop controls as not displayed even
     * after they are ready for interaction, so presence is the stable signal.
     */
    async isProjectSelectorVisible(timeoutMs = 20_000): Promise<boolean> {
        try {
            await this.waitForProjectSelector(timeoutMs);
            return true;
        } catch {
            return false;
        }
    }

    /**
     * Takes a screenshot and returns it as a base64 string.
     */
    async takeScreenshot(): Promise<string> {
        return this.driver.takeScreenshot();
    }
}
