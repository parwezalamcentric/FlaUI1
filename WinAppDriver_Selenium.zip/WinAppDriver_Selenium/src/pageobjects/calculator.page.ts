import { WebDriver, By } from 'selenium-webdriver';

export class CalculatorPage {
    private driver: WebDriver;

    constructor(driver: WebDriver) {
        this.driver = driver;
    }

    /**
     * Pause execution for the given number of milliseconds.
     * Useful to wait for the app to finish launching before interacting.
     */
    async pause(ms: number): Promise<void> {
        await new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * WinAppDriver does not support Selenium's CSS selector strategy.
     * Use XPath against Windows accessibility properties instead.
     */
    get num1()    { return this.driver.findElement(By.xpath('//*[@Name="One"]')); }
    get num2()    { return this.driver.findElement(By.xpath('//*[@Name="Two"]')); }
    get plus()    { return this.driver.findElement(By.xpath('//*[@Name="Plus"]')); }
    get equals()  { return this.driver.findElement(By.xpath('//*[@Name="Equals"]')); }
    get results() { return this.driver.findElement(By.xpath('//*[@AutomationId="CalculatorResults"]')); }

    /**
     * Reads the calculator result display and strips prefix text.
     */
    async getResult(): Promise<string> {
        const resultsEl = await this.results;
        const rawText = await resultsEl.getText();
        return rawText.replace('Display is', '').trim();
    }
}
