import { defineConfig, devices } from '@playwright/test';

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// import dotenv from 'dotenv';
// import path from 'path';
// dotenv.config({ path: path.resolve(__dirname, '.env') });

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  testDir: './tests',
  /* Run tests in files in parallel */
  fullyParallel: false, // Sequential for Local Desktop UI interaction constraints
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,
  /* Disable parallel workers completely to stabilize the WinAppDriver cursor */
  workers: 1,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: 'html',
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('')`. */
    // baseURL: 'http://localhost:3000',

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'on-first-retry',
  },

  /* Configure projects for major browsers */
  projects: [
    {
      name: 'Windows Desktop App',
      // Explicitly lock this project to the desktop test files only
      testMatch: /(^|[\\/])calculator\.spec\.ts$/,
      testIgnore: /(^|[\\/])sts.*\.spec\.ts$/,
    },
    {
      name: 'SimToolSuite',
      // Explicitly lock this project to the STS test files only
      testMatch: /(^|[\\/])sts.*\.spec\.ts$/,
      testIgnore: /(^|[\\/])calculator\.spec\.ts$/,
    },

    // Web UI tests — uncomment when Web UI testing is needed
    // {
    //   name: 'chromium',
    //   testIgnore: /.*calculator\.spec\.ts/, // Skip desktop scripts
    //   use: { ...devices['Desktop Chrome'] },
    // },

    // Uncomment to add more browsers:
    // {
    //   name: 'firefox',
    //   testIgnore: /.*calculator\.spec\.ts/,
    //   use: { ...devices['Desktop Firefox'] },
    // },
    // {
    //   name: 'webkit',
    //   testIgnore: /.*calculator\.spec\.ts/,
    //   use: { ...devices['Desktop Safari'] },
    // },
  ],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://localhost:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});
